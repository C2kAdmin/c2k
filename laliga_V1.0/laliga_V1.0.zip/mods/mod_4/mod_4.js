// mods/mod_4/mod_4.js

document.addEventListener('DOMContentLoaded', function() {
    console.log('Módulo 4 cargado.');
});
