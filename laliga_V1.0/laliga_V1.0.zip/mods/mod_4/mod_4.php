<!-- mods/mod_4/mod_4.php -->
<link rel="stylesheet" href="mods/mod_4/mod_4.css">
<script src="mods/mod_4/mod_4.js"></script>

<div class="mod_4 slide-right">
    <div class="mod_4_fila">
        <div class="mod_4_columna_1">
            <h2>Columna 1</h2>
            <p>Contenido de la columna 1.</p>
        </div>
        <div class="mod_4_columna_2">
            <h2>Columna 2</h2>
            <p>Contenido de la columna 2.</p>
        </div>
    </div>
    <div class="mod_4_fila">
        <div class="mod_4_columna_3">
            <h2>Columna 3</h2>
            <p>Contenido de la columna 3.</p>
        </div>
        <div class="mod_4_columna_4">
            <h2>Columna 4</h2>
            <p>Contenido de la columna 4.</p>
        </div>
    </div>
</div>
