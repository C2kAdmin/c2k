<!-- mods/mod_lat_izq/mod_lat_izq.php -->
<link rel="stylesheet" href="mods/mod_lat_izq/mod_lat_izq.css">
<script src="mods/mod_lat_izq/mod_lat_izq.js"></script>

<div class="mod_lat_izq slide-right">
    <div class="mod_lat_izq_columna_1">
        <h2>Contenido del Módulo Lateral Izquierdo</h2>
        <p>Este es el contenido del módulo lateral izquierdo, que tiene una sola columna.</p>
    </div>
</div>
