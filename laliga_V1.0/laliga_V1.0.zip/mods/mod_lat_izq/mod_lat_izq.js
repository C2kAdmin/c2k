// mods/mod_lat_izq/mod_lat_izq.js

document.addEventListener('DOMContentLoaded', function() {
    console.log('Módulo Lateral Izquierdo cargado.');
});
