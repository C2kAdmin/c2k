<!-- mod_antefooter_ext.php -->
<link rel="stylesheet" href="mods/mod_antefooter_ext/mod_antefooter_ext.css?<?php echo filemtime('mods/mod_antefooter_ext/mod_antefooter_ext.css'); ?>">

<div class="modulo-antefooter-ext">
    <div class="modulo-antefooter-ext-columna-1">
        <h2>Antefooter extendido</h2>
        <p>Un texto es una composición de signos codificados en un sistema de escritura que forma una unidad de sentido. También es una composición de caracteres imprimibles (con grafema) generados por un algoritmo de cifrado que, aunque no tienen sentido para cualquier persona, sí puede ser descifrado por su destinatario original. En otras palabras, un texto es un entramado de signos con una intención comunicativa que adquiere sentido en determinado contexto.</p>
    </div>
</div>
