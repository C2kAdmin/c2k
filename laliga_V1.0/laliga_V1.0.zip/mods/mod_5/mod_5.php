<!-- mods/mod_5/mod_5.php -->
<link rel="stylesheet" href="mods/mod_5/mod_5.css">
<script src="mods/mod_5/mod_5.js"></script>

<div class="mod_5 fade-in">
    <div class="mod_5_fila">
        <div class="mod_5_columna_1">
            <h2>Columna 1</h2>
            <p>Contenido de la columna 1.</p>
        </div>
        <div class="mod_5_columna_2">
            <h2>Columna 2</h2>
            <p>Contenido de la columna 2.</p>
        </div>
    </div>
    <div class="mod_5_fila">
        <div class="mod_5_columna_3">
            <h2>Columna 3</h2>
            <p>Contenido de la columna 3.</p>
        </div>
        <div class="mod_5_columna_4">
            <h2>Columna 4</h2>
            <p>Contenido de la columna 4.</p>
        </div>
    </div>
    <div class="mod_5_columna_5">
        <h2>Columna 5</h2>
        <p>Contenido de la columna 5.</p>
    </div>
</div>
