// mods/mod_5/mod_5.js

document.addEventListener('DOMContentLoaded', function() {
    console.log('Módulo 5 cargado.');
});
