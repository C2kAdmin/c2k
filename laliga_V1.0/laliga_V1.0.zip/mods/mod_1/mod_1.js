// mods/mod_1/mod_1.js

document.addEventListener('DOMContentLoaded', function() {
    console.log('Módulo 1 cargado.');
});
