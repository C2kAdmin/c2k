// mods/mod_3/mod_3.js

document.addEventListener('DOMContentLoaded', function() {
    console.log('Módulo 3 cargado.');
});
