<!-- mods/mod_3/mod_3.php -->
<link rel="stylesheet" href="mods/mod_3/mod_3.css">
<script src="mods/mod_3/mod_3.js"></script>

<div class="mod_3 slide-left">
    <div class="mod_3_columna_1">
        <h2>Contenido Columna 1 del Módulo 3</h2>
        <p>Este es el contenido de la primera columna del módulo 3.</p>
    </div>
    <div class="mod_3_columna_2">
        <h2>Contenido Columna 2 del Módulo 3</h2>
        <p>Este es el contenido de la segunda columna del módulo 3.</p>
    </div>
    <div class="mod_3_columna_3">
        <h2>Contenido Columna 3 del Módulo 3</h2>
        <p>Este es el contenido de la tercera columna del módulo 3.</p>
    </div>
</div>
