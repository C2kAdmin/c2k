// mods/mod_lat_der/mod_lat_der.js

document.addEventListener('DOMContentLoaded', function() {
    console.log('Módulo Lateral Derecho cargado.');
});
