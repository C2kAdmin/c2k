<!-- mods/mod_lat_der/mod_lat_der.php -->
<link rel="stylesheet" href="mods/mod_lat_der/mod_lat_der.css">
<script src="mods/mod_lat_der/mod_lat_der.js"></script>

<div class="mod_lat_der slide-left">
    <div class="mod_lat_der_columna_1">
        <h2>Contenido del Módulo Lateral Derecho</h2>
        <p>Este es el contenido del módulo lateral derecho, que tiene una sola columna.</p>
    </div>
</div>
