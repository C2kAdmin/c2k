<!-- mods/mod_2/mod_2.php -->
<link rel="stylesheet" href="mods/mod_2/mod_2.css">
<script src="mods/mod_2/mod_2.js"></script>

<div class="mod_2 fade-in">
    <div class="mod_2_columna_1">
        <h2>Contenido Columna 1 del Módulo 2</h2>
        <p>Este es el contenido de la primera columna del módulo 2.</p>
    </div>
    <div class="mod_2_columna_2">
        <h2>Contenido Columna 2 del Módulo 2</h2>
        <p>Este es el contenido de la segunda columna del módulo 2.</p>
    </div>
</div>
