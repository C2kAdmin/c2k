// mods/mod_2/mod_2.js

document.addEventListener('DOMContentLoaded', function() {
    console.log('Módulo 2 cargado.');
});
