<?php
    header("Cache-Control: no-cache, must-revalidate");
    header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
?>
<!-- mods/mod_izq_flot/mod_izq_flot.php -->
<link rel="stylesheet" href="mods/mod_izq_flot/mod_izq_flot.css">
<script src="mods/mod_izq_flot/mod_izq_flot.js"></script>

<div class="mod_izq_flot">
    <div class="mod_izq_flot_columna_1">
        <h2>Módulo Flotante</h2>
        <p>Este módulo se mantiene visible mientras haces scroll.</p>
    </div>
</div>
