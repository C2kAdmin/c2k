<!-- mods/mod_youtube/mod_youtube.php -->
<link rel="stylesheet" href="mods/mod_youtube/mod_youtube.css">
<script src="mods/mod_youtube/mod_youtube.js"></script>

<div class="mod_youtube">
    <div class="mod_youtube_columna_1">
        <div class="video-container">
            <div id="video-player"></div>
        </div>
        <div class="carousel-wrapper">
            <div class="carousel-container" id="video-list"></div>
        </div>
    </div>
</div>
