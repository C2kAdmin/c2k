// mods/mod_6/mod_6.js

document.addEventListener('DOMContentLoaded', function() {
    console.log('Módulo 6 cargado.');
});
