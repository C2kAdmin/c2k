<!-- mods/mod_recuperar/mod_recuperar.php -->
<link rel="stylesheet" href="mods/mod_recuperar/mod_recuperar.css">
<script src="mods/mod_recuperar/mod_recuperar.js"></script>

<div class="modulo-recuperar">
    <h2>Recuperar Contraseña</h2>
    <form id="recuperarForm" method="POST">
        <div class="form-grupo">
            <input type="email" id="email" name="email" placeholder="Correo Electrónico" required>
        </div>
        <div class="form-grupo-boton">
            <button type="submit">Enviar Enlace de Recuperación</button>
        </div>
    </form>
</div>
