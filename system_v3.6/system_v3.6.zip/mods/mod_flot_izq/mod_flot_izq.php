<!-- mods/mod_flot_izq/mod_flot_izq.php -->
<link rel="stylesheet" href="mods/mod_flot_izq/mod_flot_izq.css">
<script src="mods/mod_flot_izq/mod_flot_izq.js"></script>

<div class="mod_flot_izq slide-right">
    <div class="mod_flot_izq_columna_1">
        <h2>Contenido del Módulo Flotante Izquierdo</h2>
        <p>Este es el contenido del módulo flotante izquierdo, que tiene una sola columna.</p>
    </div>
</div>
