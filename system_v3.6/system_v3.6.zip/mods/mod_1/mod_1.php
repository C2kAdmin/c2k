<!-- mods/mod_1/mod_1.php -->
<link rel="stylesheet" href="mods/mod_1/mod_1.css">
<script src="mods/mod_1/mod_1.js"></script>

<div class="mod_1 slide-up">
    <div class="mod_1_columna_1">
        <h2>Contenido del Módulo 1</h2>
        <p>Este es el contenido del módulo 1, que tiene una sola columna.</p>
    </div>
</div>
